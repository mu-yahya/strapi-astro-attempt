declare module "astro:actions" {
	type Actions = typeof import("C:/Users/yahya/virtual-ellipse/src/actions")["server"];

	export const actions: Actions;
}