/// <reference types="astro/client" />
/// <reference path="astro/actions.d.ts" />