/*export default function createIntegration() {
    return {
      name: '@yahya/my-adapter',
      hooks: {
        'astro:config:done': ({ setAdapter }) => {
          setAdapter({
            name: '@yahya/my-adapter',
            serverEntrypoint: '@yahya/my-adapter/server.js',
            exports: ['handler'],
            supportedAstroFeatures: {
                staticOutput: 'stable'
            }
          });
        },
      },
    };
  }*/